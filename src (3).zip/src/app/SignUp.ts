export interface SignUp {
  userid:string;
  email:string;
  password:string;
}
