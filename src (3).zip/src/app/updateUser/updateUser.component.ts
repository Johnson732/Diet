import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { DiettrackerService } from './../diettracker.service';
 // Assuming UserService is the service to fetch and update user data

@Component({
  selector: 'app-updateUser',
  templateUrl: './updateUser.component.html',
  styleUrls: ['./updateUser.component.css']
})
export class UpdateUserComponent implements OnInit {
  formData: {
    UserId: string;
    FirstName: string;
    LastName: string;
    Dob: Date;
    UserGender: number;
    Height: number;
    Weight: number;
    ExerciseLevel: number;
    UserGoal: number;
  } = {
    UserId: this.diettracker.getuserid(),
    FirstName: '',
    LastName: '',
    Dob: new Date(),
    UserGender: 0,
    Height: 0,
    Weight: 0,
    UserGoal: 0,
    ExerciseLevel: 0,
  };
  sharedData: any;
  constructor(private diettracker: DiettrackerService) {

  }

  ngOnInit() {
    // Fetch user data when component initializes
    const userId = this.diettracker.getuserid();
    if (userId) {
      this.diettracker.fetchUser(userId).subscribe(
        (user) => {
          // Assign fetched user data to form data
          this.formData = {
            UserId: this.formData.UserId,
            FirstName: user.firstname,
            LastName: user.lastname,
            Dob: user.dob,
            UserGender: user.usergender,
            Height: user.height,
            Weight: user.weight,
            UserGoal: user.usergoal,
            ExerciseLevel: user.exerciselevel
          };
        },
        (error) => {
          console.error('Error fetching user data:', error);
        }
      );
    } else {
      console.error('UserId is not set.');
    }
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      const formData = { ...form.value, UserId: this.formData.UserId };
      console.log('Form Data:', formData);
      this.diettracker.updateUser(formData).subscribe(
        (response) => {
          console.log('User details updated', response);
          form.resetForm();
        },
        (error) => {
          console.error('Error updating user data:', error);
          if (error instanceof HttpErrorResponse) {
            if (error.status === 400 && error.error && error.error.errors) {
              // Handle validation errors
              console.error('Validation errors:', error.error.errors);
            } else {
              // Handle other errors
              console.error('Other error:', error.statusText);
            }
          } else {
            // Handle non-HTTP errors
            console.error('Non-HTTP error:', error);
          }
        }
      );
    }
  }
}
