export interface ViewFood {
  ServingSizeNavigation: any;
  Meal: any;

  UserId: string;
  MealName: string;
  FoodName: string;
  UnitSize: number;
  CreatedOn: Date;
  Quantity: number;
}
