import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndexComponent } from './index.component';
import { LandingComponent } from './landing/landing.component';
import { AddFoodComponent } from '../dashboard/addFood/addFood.component';
import { AppComponent } from '../app.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { AddUserComponent } from '../addUser/addUser.component';
import { Delete2Component } from '../delete2/delete2.component';
import { DeleteFoodComponent } from '../deleteFood/deleteFood.component';
import { FilterComponent } from '../filter/filter.component';
import { FilterviewComponent } from '../filterview/filterview.component';
import { FoodDetailsComponent } from '../foodDetails/foodDetails.component';
import { UpdateUserComponent } from '../updateUser/updateUser.component';
import { ViewfoodComponent } from '../viewfood/viewfood.component';

const routes: Routes = [
  {
    path: '',
    component: IndexComponent,
    children: [{ path: '', component: LandingComponent }],
  },
  //{path:'AddFood',component:AddFoodComponent},
  {
    path: '',
    component: DashboardComponent,
    children: [
      { path: 'AddFood', component: AddFoodComponent },
      { path: 'AddUser', component: AddUserComponent },
      { path: 'ViewFood', component: ViewfoodComponent },
      { path: 'Update', component: UpdateUserComponent },
      { path: 'FoodDetails/:foodName/:userId', component: FoodDetailsComponent },
      { path: 'DeleteFood/:userId/:createdon', component: DeleteFoodComponent },
      { path: 'Delete2/:userId/:createdon', component: Delete2Component },
      { path: 'Filterview', component: FilterviewComponent },
      { path: 'Filter/:userid', component: FilterComponent },


    ],
  },
  // {
  //   path:'AddFood',
  //   component:AppComponent,
  //   children:[{path:'AddFood',component:AddFoodComponent}]
  // },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IndexRoutingModule {}
