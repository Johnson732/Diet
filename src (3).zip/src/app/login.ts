export interface Login {
  firstTimeLogin: any;
  userid: string;
  password: string;
}
