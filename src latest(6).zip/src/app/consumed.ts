export interface Consumed {
  calories:number;
}
