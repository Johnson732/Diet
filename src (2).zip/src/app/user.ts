export interface User {
  userid:string;
  firstname:string;
  lastname:string;
  dob:Date;
  usergender:number;
  height:number;
  weight:number;
  exerciselevel:number;
  usergoal:number;
}
