import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModel } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { DiettrackerService } from './../diettracker.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  formData: { UserId: string; Password: string } = {
    UserId: '',
    Password: '',
  };
  // userid:string=this.formData.UserId;
  // password:string=this.formData.Password;
  constructor(private diettracker: DiettrackerService) {}

  ngOnInit() {

    // const dataemail = this.email;
    // this.diettracker.setemail(dataemail);

    // const datapwd = this.password;
    // this.diettracker.setpwd(datapwd);
  }
  onSubmit(form: NgForm) {
    if (form.valid) {
      const formData = form.value;
    console.log('Form Data:', formData);
    this.diettracker.setuserid(formData.Userid); // Use Userid instead of UserId
    console.log('UserID:', this.diettracker.getuserid());
      this.diettracker.userLogin(formData).subscribe(
        (response) => {
          console.log('User logged in', response);
          form.resetForm();
        },
        (error) => {
          console.error('Error login data:', error);
          if (error instanceof HttpErrorResponse) {
            if (error.status === 400 && error.error && error.error.errors) {
              // Handle validation errors
              console.error('Validation errors:', error.error.errors);
            } else {
              // Handle other errors
              console.error('Other error:', error.statusText);
            }
          } else {
            // Handle non-HTTP errors
            console.error('Non-HTTP error:', error);
          }
        }
      );
    }
  }

}
