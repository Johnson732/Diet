export interface AddFood {
  UserId:string;
  MealId: number;
  FoodName: string;
  ServingSize: number;
  Quantity: number;
}
