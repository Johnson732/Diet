export interface User {
  gendervalue: any;
  UserGenderNavigation: any;

  userid:string;
  firstname:string;
  lastname:string;
  dob:Date;
  usergender:number;
  height:number;
  weight:number;
  exerciselevel:number;
  usergoal:number;
}
