import { NgModule, Component } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AddUserComponent } from './addUser/addUser.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AddFoodComponent } from './addFood/addFood.component';
import { ViewfoodComponent } from './viewfood/viewfood.component';
import { FoodDetailsComponent } from './foodDetails/foodDetails.component';
import { DeleteFoodComponent } from './deleteFood/deleteFood.component';
import { Delete2Component } from './delete2/delete2.component';
const routes: Routes = [
  // { path: '', component: HomeComponent },
  { path: 'SignUp', component: SignUpComponent },
  { path: 'Login', component: LoginComponent },
  { path: 'AddUser', component: AddUserComponent },
  { path: 'AddFood', component: AddFoodComponent },
  { path: 'ViewFood', component: ViewfoodComponent },
  { path: 'FoodDetails/:foodName/:userId', component: FoodDetailsComponent },
  { path: 'DeleteFood/:userId/:createdon', component: DeleteFoodComponent },
  { path: 'Delete2/:userId/:createdon', component: Delete2Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
