import { DiettrackerService } from './../diettracker.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgModel } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css'],
})
export class SignUpComponent implements OnInit {
  formData: { UserId: string; Email: string; Password: string } = {
    UserId: '',
    Email: '',
    Password: '',
  };
  userid:string=this.formData.UserId;
  email:string=this.formData.Email;
  password:string=this.formData.Password;
  constructor(private diettracker: DiettrackerService) {}


  ngOnInit() {
   
  }

  onSubmit(form: NgForm) {
    if (form.valid) {
      const formData = form.value;
      this.diettracker.addNewSignUp(formData).subscribe(
        (response) => {
          console.log('New User Signed Up', response);
          form.resetForm();
        },
        (error) => {
          console.error('Error adding new user sign up data:', error);
          if (error instanceof HttpErrorResponse) {
            if (error.status === 400 && error.error && error.error.errors) {
              // Handle validation errors
              console.error('Validation errors:', error.error.errors);
            } else {
              // Handle other errors
              console.error('Other error:', error.statusText);
            }
          } else {
            // Handle non-HTTP errors
            console.error('Non-HTTP error:', error);
          }
        }
      );
    }
  }
}
